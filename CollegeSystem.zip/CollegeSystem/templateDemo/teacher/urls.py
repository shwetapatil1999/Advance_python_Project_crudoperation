from django.urls import path
from teacher import views

urlpatterns = [
    
 
    path('teacher/',views.index1,name="teacher-home"),
    path('show1/',views.show1,name="Display teacher List"),
    path('edit1/<int:id>',views.edit1,name="Edit teacher List"),
    path('update1/<int:id>',views.update1,name='Update'),
    path('delete1/<int:id>',views.destroy1,name="Delete teacher Record"),

    

]