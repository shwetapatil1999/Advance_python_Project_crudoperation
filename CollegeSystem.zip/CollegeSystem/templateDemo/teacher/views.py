from tkinter import E
from django.shortcuts import render,HttpResponse,redirect
#loading StudentForm from form.py inside students app
#from app_name.form import ModelForm_name
from teacher.form import TeacherForm
from teacher.models import Teacher
# Create your views here.
def index1(request):
    if request.method=="POST":
        form=TeacherForm(request.POST)
        if form.is_valid():
            form.save()#persist data in database, using queryset(Django ORM API) method ==> create
            return redirect('../show1')
            #return render(request,'show.html',{'form':form})
        else:
            pass
    else:
        obj=TeacherForm()
        return render(request,'index1.html',{'stu':obj}) #HTTP GET Method for displaying an empty form
        
def show1(request):  
        students = Teacher.objects.all()  #similar to select * from student
        return render(request,"show1.html",{'stu_list':students})  


#just display a form with filled fields
def edit1(request, id):  
        stu = Teacher.objects.get(id=id)  
        return render(request,'edit1.html', {'stu':stu})

def update1(request, id):  
        stu =Teacher.objects.get(id=id)  
        form=TeacherForm(request.POST, instance = stu)  
        if form.is_valid():  
            form.save()  
            return redirect("../show1")
            #return render(request,'show.html')
        return render(request, 'edit1.html', {'stu': stu})  

def destroy1(request, id):  
    stu=Teacher.objects.get(id=id)  
    stu.delete() 
    return redirect("../show1") 
    #return render(request,'show.html')
   
   

def new_func():
    return redirect('show1')
    
    
def upload1(request):
    obj=TeacherForm()
    return render(request,'upload1.html',{'stu':obj})

