from django import forms
#import model class from models.py
#from app_name.models import model_name
from teacher.models import Teacher

class TeacherForm(forms.ModelForm):
    class Meta:
        model=Teacher
        fields="__all__"
